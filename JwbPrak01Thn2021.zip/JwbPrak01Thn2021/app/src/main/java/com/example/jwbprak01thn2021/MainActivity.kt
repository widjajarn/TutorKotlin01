package com.example.jwbprak01thn2021

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    var jumlangkah: Int = 50
    var papan = mutableListOf<MutableList<Button>>()
    var board = ArrayList<ArrayList<Button>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // cara pertama
//        var temp0 = mutableListOf<Button>()
//        temp0.add(btn00);        temp0.add(btn01)
//        temp0.add(btn02);        temp0.add(btn03)
//        papan.add(temp0)
//        var temp1 = mutableListOf<Button>()
//        temp1.add(btn10);        temp1.add(btn11)
//        temp1.add(btn12);        temp1.add(btn13)
//        papan.add(temp1)
//        var temp2 = mutableListOf<Button>()
//        temp2.add(btn20);        temp2.add(btn21)
//        temp2.add(btn22);        temp2.add(btn23)
//        papan.add(temp2)
//        var temp3 = mutableListOf<Button>()
//        temp3.add(btn30);        temp3.add(btn31)
//        temp3.add(btn32);        temp3.add(btn33)
//        papan.add(temp3)

        // cara kedua
//        papan.add(mutableListOf<Button>(btn00, btn01, btn02, btn03))
//        papan.add(mutableListOf<Button>(btn10, btn11, btn12, btn13))
//        papan.add(mutableListOf<Button>(btn20, btn21, btn22, btn23))
//        papan.add(mutableListOf<Button>(btn30, btn31, btn32, btn33))

        // cara ketiga
        papan = mutableListOf(
            mutableListOf<Button>(btn00, btn01, btn02, btn03),
            mutableListOf<Button>(btn10, btn11, btn12, btn13),
            mutableListOf<Button>(btn20, btn21, btn22, btn23),
            mutableListOf<Button>(btn30, btn31, btn32, btn33),
        )

        // cara keempat
//        var t0 = ArrayList<Button>()
//        t0.add(btn00); t0.add(btn01); t0.add(btn02); t0.add(btn03);
//        board.add(t0)
//        var t1 = ArrayList<Button>()
//        t1.add(btn10); t1.add(btn11); t1.add(btn12); t1.add(btn13);
//        board.add(t1)
//        var t2 = ArrayList<Button>()
//        t2.add(btn20); t2.add(btn21); t2.add(btn22); t2.add(btn23);
//        board.add(t2)
//        var t3 = ArrayList<Button>()
//        t3.add(btn30); t3.add(btn31); t3.add(btn32); t3.add(btn33);
//        board.add(t3)

        for(brs in 0..3) {
            for(klm in 0..3) {
//                papan[brs][klm].setEnabled(false)
                papan[brs][klm].setText("")
                papan[brs][klm].setEms(0)                   // property yg dipakai utk simpan saat itu warna merah / biru
                papan[brs][klm].setTag(brs.toString() + "-" + klm.toString())

                papan[brs][klm].setBackgroundColor(Color.BLUE)
                papan[brs][klm].setOnClickListener(View.OnClickListener {
                    ditekan(it)
                })
            }
        }
    }

    fun ditekan(it: View) {
        // menggunakan tag nya
        var nilaitag: String = it.tag.toString()
        Toast.makeText(baseContext, "nilaitag = " + nilaitag, Toast.LENGTH_SHORT).show()

        var node     = nilaitag.split("-")
        var baris    = node[0].toInt()
        var kolom    = node[1].toInt()

        // atas
        if(papan[baris-1][kolom].minEms == 0) {
            papan[baris-1][kolom].setBackgroundColor(Color.RED)
            papan[baris-1][kolom].setEms(1)
        }
        else {
            papan[baris-1][kolom].setBackgroundColor(Color.BLUE)
            papan[baris-1][kolom].setEms(0)
        }
        // bawah
        if(papan[baris+1][kolom].minEms == 0) {
            papan[baris+1][kolom].setBackgroundColor(Color.RED)
            papan[baris+1][kolom].setEms(1)
        }
        else {
            papan[baris+1][kolom].setBackgroundColor(Color.BLUE)
            papan[baris+1][kolom].setEms(0)
        }
        // kiri
        if(papan[baris][kolom-1].minEms == 0) {
            papan[baris][kolom-1].setBackgroundColor(Color.RED)
            papan[baris][kolom-1].setEms(1)
        }
        else {
            papan[baris][kolom-1].setBackgroundColor(Color.BLUE)
            papan[baris][kolom-1].setEms(0)
        }
        // kanan
        if(papan[baris][kolom+1].minEms == 0) {
            papan[baris][kolom+1].setBackgroundColor(Color.RED)
            papan[baris][kolom+1].setEms(1)
        }
        else {
            papan[baris][kolom+1].setBackgroundColor(Color.BLUE)
            papan[baris][kolom+1].setEms(0)
        }


        // menggunakan id nya
//        var namaobjek = getResources().getResourceEntryName(it.id)
//        Toast.makeText(baseContext, "anda tekan = " + namaobjek, Toast.LENGTH_SHORT).show()
//        var brs = namaobjek.substring(3, 4).toInt() // btn00
//        var klm = namaobjek.substring(4, 5).toInt() // 01234
//        if(papan[brs][klm].tag.toString().equals("0")) {
//            papan[brs][klm].setBackgroundColor(Color.CYAN)
//            papan[brs][klm].setTag("1");
//        }
//        else {
//            papan[brs][klm].setBackgroundColor(Color.BLUE)
//            papan[brs][klm].setTag("0");
//        }
//
//        jumlangkah-=1
//        txtscore.setText("Moves : " + jumlangkah.toString())
    }
}